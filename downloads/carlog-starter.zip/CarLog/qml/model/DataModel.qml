import Felgo
import QtQuick
import "../logic/FuelRecordValidation.js" as FuelRecordValidation

Item {
  id: root

  // property to configure target dispatcher / logic
  property alias dispatcher: logicConnection.target

  property string carName: ""
  property bool onboardingCompleted: false
  property var fuelRecords: []
  property string fuelRecordsError: ""
  property var lastStorageError: null
  signal fuelRecordDeleted()
  signal fuelRecordDeleteFailed(string message)
  signal fuelRecordSaved()
  signal fuelRecordSaveFailed(var errors, string message)

  function prepare() {
    // Restore saved registration and records on startup.
  }

  // Load saved fuel records, or use an empty list on first launch.
  function loadFuelRecords() {
    // Clear any error from the previous operation.
    lastStorageError = null
    const records = storage.getValue("fuelRecords")
    const isMissing = records === null || records === undefined
    if (isMissing) {
      fuelRecords = []
      fuelRecordsError = ""
      return
    }

    // getValue() runs synchronously. If it emits storageError, onStorageError
    // sets lastStorageError before getValue() returns, so we can check it below.
    if (lastStorageError) {
      fuelRecordsError = qsTr("Fuel records could not be loaded. Restart the app to try again.")
      return
    }

    fuelRecords = records
    fuelRecordsError = ""
  }

  // Give each record a stable identity independent of its date or list position.
  function createRecordId() {
    return Date.now().toString(36) + "-" + Math.random().toString(36).slice(2)
  }

  // Publish changes only after the synchronous Storage call succeeds.
  function storeFuelRecords(records) {
    // Save records before updating the list.
    return false
  }

  // Validate and save either a new record or changes to the selected record.
  function saveFuelRecord(draft, recordId) {
    fuelRecordSaveFailed({}, qsTr("Saving is not connected yet."))
  }

  // Delete only the selected record and keep the list unchanged if saving fails.
  function deleteFuelRecord(recordId) {
    fuelRecordDeleteFailed(qsTr("Deletion is not connected yet."))
  }

  Connections {
    target: storage
    function onStorageError(errorData) {
      // Capture errors emitted during the current Storage call.
      root.lastStorageError = errorData
    }
  }

  function completeOnboarding(name) {
    // Save registration after the onboarding screen is built. This starter keeps it only in memory.
    carName = name.trim()
    onboardingCompleted = true
    return true
  }

  // Clear registration and fuel records for a fresh start.
  function resetOnboarding() {
    storage.setValue("carName", "")
    storage.setValue("onboardingCompleted", false)
    storage.setValue("fuelRecords", [])
    root.carName = ""
    root.fuelRecords = []
    root.fuelRecordsError = ""
    root.onboardingCompleted = false
  }

  // listen to actions from dispatcher
  Connections {
    id: logicConnection

    function onOnboardingFinished(carName) {
      completeOnboarding(carName)
    }

    function onOnboardingReset() {
      resetOnboarding()
    }

    function onUpdateFuelRecord(recordId, draft) {
      saveFuelRecord(draft, recordId)
    }

    function onDeleteFuelRecord(recordId) {
      deleteFuelRecord(recordId)
    }

    function onAddFuelRecord(draft) {
      saveFuelRecord(draft)
    }
  }

  Component.onCompleted: {
    prepare()
  }
}
