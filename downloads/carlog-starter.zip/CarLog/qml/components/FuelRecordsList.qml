import QtQuick
import QtQuick.Layouts
import Felgo

ColumnLayout {
  id: root
  property var records: []
  property bool editable: false
  property SlideInAnimation entranceAnimation: null
  property string emptyTitle: qsTr("No fuel records yet")
  property string emptyDescription: ""
  property string errorMessage: ""
  property bool recordsVisible: true
  property real emptyOpacity: 1
  readonly property int count: recordsView.count
  signal recordClicked(var record)

  spacing: dp(16)

  StyledText {
    Layout.fillWidth: true
    visible: root.errorMessage.length > 0
    text: root.errorMessage
    color: Theme.colors.tintColor
    wrapMode: Text.WordWrap
  }

  Item {
    Layout.fillWidth: true
    Layout.fillHeight: true
    visible: root.recordsVisible

    Column {
      anchors.centerIn: parent
      width: parent.width
      spacing: dp(8)
      visible: recordsView.count === 0 && !root.errorMessage
      opacity: root.emptyOpacity

      StyledText {
        width: parent.width
        text: root.emptyTitle
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        font.weight: root.emptyDescription ? Font.DemiBold : Font.Normal
        color: root.emptyDescription ? Theme.listItem.textColor : Theme.listItem.detailTextColor
      }
      StyledText {
        width: parent.width
        visible: root.emptyDescription.length > 0
        text: root.emptyDescription
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        color: Theme.listItem.detailTextColor
        font.pixelSize: sp(14)
      }
    }

    ListView {
      id: recordsView
      anchors.fill: parent
      clip: true
      spacing: dp(12)
      model: root.records
    }
  }
}
