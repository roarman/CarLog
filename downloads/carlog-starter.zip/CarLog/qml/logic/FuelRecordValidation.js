.pragma library

// Validate input and return the result, field errors, and numeric values to store.
function validate(draft) {
  return {valid: false, errors: {}, record: {}}
}

// Trim whitespace and replace a decimal comma with a decimal point.
function numberText(value) {
  return String(value === undefined ? "" : value).trim().replace(",", ".")
}

// Check for a valid date in yyyy-MM-dd format that is not in the future.
function isValidDate(text) {
  const date = new Date(text + "T00:00:00")
  return Qt.formatDate(date, "yyyy-MM-dd") === text && date <= new Date()
}
