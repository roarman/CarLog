import QtQuick
import QtQuick.Layouts
import Felgo
import "../design"
import "../components"

AppPage {
  id: root
  navigationBarHidden: true

  signal onboardingFinished(string carName)

  property TransitionOverlay transitionOverlay: null
  property bool departureRunning: false
  property string pendingCarName: ""

  function resetForm() {
    carNameField.clear()
  }

  function revealMainPage() {
    root.transitionOverlay.reveal()
  }

  Connections {
    target: root.transitionOverlay

    function onCovered() {
      // Emit registration after the overlay covers the screen.
    }

    function onFinished() {
      root.pendingCarName = ""
      root.departureRunning = false
      carTranslation.x = 0
    }
  }

  Column {
    id: column
    anchors.fill: parent
    anchors.margins: dp(20)
    spacing: dp(10)
    enabled: !root.departureRunning

    // Spacer
    Item {
      width: 1
      height: dp(40)
    }

    AppText {
      anchors.horizontalCenter: parent.horizontalCenter
      font.pixelSize: sp(24)
      font.bold: true
      text: qsTr("WELCOME TO CAR LOG")
    }

    AppImage {
      id: carImage
      anchors.horizontalCenter: parent.horizontalCenter
      source: "../../assets/car.png"
      width: parent.width * 0.7
      height: width * 0.7

      fillMode: AppImage.PreserveAspectFit
      transform: Translate { id: carTranslation }
    }

    // Add the car-name row below the image.

    // Add the registration button below the name row.
  }

  NumberAnimation {
    id: carDeparture
    target: carTranslation
    property: "x"
    from: 0
    to: root.width + carImage.width
    duration: 450
    easing.type: Easing.InCubic
  }
}
