# CarLog starter

Requires a configured Felgo desktop kit with Qt 6.8.3.
Follow the CarLog tutorial. The starter supplies reusable components;
wire the model, build the list and form, then add validation and persistence.
The solution contains the current app source.
